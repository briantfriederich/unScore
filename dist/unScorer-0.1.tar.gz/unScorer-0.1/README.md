# unScore
Simple Python programming changing scores into modern numbers
