from setuptools import setup

setup(name='unScorer',
      version="0.1",
      packages = ['unScorer'],
      include_package_data=True,
      author = "Brian Friederich",
      author_email = "briantfriederich@gmail.com",
      zip_safe=False)
