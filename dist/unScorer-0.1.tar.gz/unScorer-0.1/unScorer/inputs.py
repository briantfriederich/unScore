class Text:
  def __init__(self, string):
    self.string = string
